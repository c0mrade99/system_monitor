#include <string>

#include "format.h"//Include format.h

using std::string;

// TODO: Complete this helper function
// INPUT: Long int measuring seconds

// REMOVE: [[maybe_unused]] once you define the function
std::string Format::ElapsedTime(long seconds) { 

    //Number of seconds in a minute
    const int SECPERMIN =60;
    //Number of seconds in an hours
    const int SECPERHOUR =3600;
    // INPUT: Long int measuring seconds 
  
    //Get Seconds
    long lseconds = seconds % SECPERMIN;
    // Get Minutes
    long lminutes = (seconds / SECPERMIN) %SECPERMIN;
    // Get Hours
    long lhours   = seconds /SECPERHOUR; 
    std::stringstream ssresult;
	// OUTPUT: HH:MM:SS
    ssresult << std::setfill('0') << std::setw(2) << lhours << ":";
    ssresult << std::setfill('0') << std::setw(2) << lminutes << ":";  
    ssresult << std::setfill('0') << std::setw(2) << lseconds; 

    return ssresult.str();
}