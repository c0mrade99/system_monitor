#ifndef FORMAT_H
#define FORMAT_H
#include <iomanip>
#include <string>
#include <sstream>

namespace Format 
{
std::string ElapsedTime(long times);  // TODO: See src/format.cpp
};                                    // namespace Format

#endif